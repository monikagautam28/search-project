import React from 'react';
import react from 'react';

class News extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        return(
            <>
            <h1>this is my monika</h1>
            </>
        )
    }
    


}

export default News;