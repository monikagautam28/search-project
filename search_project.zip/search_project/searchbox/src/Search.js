import React from 'react';
import './Search.css';



class Search extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      search: "",
      data:this.props.list
    }
    }
  
  render() {
    let terms = "";
    if (this.state.search) {
      terms = this.state.search.toLowerCase();
  }
    return (<div><input type="text" onChange={(ev)=>{this.setState({search:ev.target.value})}} value={this.state.search}></input>
      <div className="cards">

        {
         this.state.data.filter((it) => 
                                            it.name.toLowerCase().includes(terms)||
                                            it.name.toUpperCase().includes(terms)
                            ).map(it => {
              return <div className="card">
              <h2 className="align_center">{it.name}</h2>
            </div>
            
           
            
          })
        }
      </div>





    </div>);
  }
}

export default Search;