import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
import Search from './Search';

function App() {
 let data=[{
  name:'canada'
},{name:'china'},
{name:'usa'},
{name:'london'},
{name:'europe'},
{name:'belgium'},
{name:'japan'},
{name:'south africa'},
{name:'doha'},
{name:'seria'},
{name:'australia'},
{name:'nigeria'},
{name:'nepal'},
{name:'dubai'},
{name:'paris'}
]

// onChnage =()=>{
//   setName("navpreet")
// }
  return (

<>
<Search list={data}/>
</>
   



  );
}

export default App;
